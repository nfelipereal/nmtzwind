from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import CallbackContext

def servicos(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    query.answer()
    query.delete_message()
    
    keyboard = [
        [InlineKeyboardButton("Reações para Canais Telegram", callback_data='menu_reacoes')],
        [InlineKeyboardButton("Voltar", callback_data='start')]
    ]
    
    query.message.reply_photo(
        photo=open('assets/servicos.png', 'rb'),
        caption='Escolha uma opção:',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
