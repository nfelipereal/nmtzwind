from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import CallbackContext

def ajuda(update: Update, context: CallbackContext) -> None:
    user = update.effective_user
    if update.callback_query:
        query = update.callback_query
        query.answer()
        query.delete_message()
        query.message.reply_photo(
            photo=open('assets/ajuda.png', 'rb'),
            caption=f'**Olá !, {user.first_name}!\n\nSou seu assistente de reações para canais no Telegram!\n\nPara usar nosso serviço, siga estas simples etapas:\n\n**Acessar o Menu Serviços:**\n1. Abra o menu principal e selecione "Serviços".\n\n**Escolher o Serviço:**\nSelecione "Reações para canais Telegram".\n\n**Configurar sua Reação:**\nEscolha a quantidade desejada de reações.\nDigite o @ do canal Telegram onde deseja aplicar as reações.\n\nImportante: Certifique-se de inserir o @ do seu canal no Telegram. Links ou IDs do canal não funcionam.\n\nNo Menu Principal, você pode repetir a última ação realizada para facilitar seu uso.',
            reply_markup=get_back_keyboard(),
            parse_mode='Markdown'
        )

def get_back_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
        [
            InlineKeyboardButton("◀️ Voltar", callback_data='start')
        ]
    ]
    return InlineKeyboardMarkup(keyboard)
