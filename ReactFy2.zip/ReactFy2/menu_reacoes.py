from telegram import InlineKeyboardMarkup, InlineKeyboardButton, Update
from telegram.ext import CallbackContext
import asyncio
from pyrogram import Client
from pyrogram.raw.functions.messages import GetMessagesViews
import os
import random
import re
import threading
import time
import sqlite3

# Emojis que você quer usar
emojis = ['❤️', '🔥', '👏', '👍', '😍']

# Diretório onde os arquivos de sessão estão armazenados
session_dir = "."
session_files = sorted(os.listdir(session_dir))
# Defina suas credenciais do Telegram
API_ID = '29211349'
API_HASH = '629a7c80baef0c9ca10af1e9445640eb'

# Função para salvar as preferências
def save_preferences(qtd, canal, ativo):
    with open('save_preferences.txt', 'w') as file:
        file.write(f'qtd={qtd}\n')
        file.write(f'canal={canal}\n')
        file.write(f'ativo={ativo}\n')

# Função para carregar as preferências
def load_preferences():
    if not os.path.exists('save_preferences.txt'):
        return None, None, False
    
    with open('save_preferences.txt', 'r') as file:
        lines = file.readlines()
        if len(lines) < 3:
            return None, None, False
        qtd = lines[0].strip().split('=')[1]
        canal = lines[1].strip().split('=')[1]
        ativo = lines[2].strip().split('=')[1] == 'True'
        if qtd and canal:
            return int(qtd), canal, ativo
        return None, None, False

# Variável global para controlar o estado de execução do bot
bot_ativo = False

def reacoes(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    query.answer()
    query.delete_message()
    
    keyboard = [
        [InlineKeyboardButton("▶️ Enviar 10 reações", callback_data='enviar_10_reacoes')],
        [InlineKeyboardButton("▶️ Enviar 20 reações", callback_data='enviar_20_reacoes')],
        [InlineKeyboardButton("▶️ Enviar 30 reações", callback_data='enviar_30_reacoes')],
        [InlineKeyboardButton("◀️ Voltar", callback_data='menu_servicos')]
    ]
    
    query.message.reply_photo(
        photo=open('assets/reacoes.png', 'rb'),
        caption='Escolha uma opção:',
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

def escolher_canal_grupo(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    query.answer()

    # Armazena a quantidade de reações no contexto do usuário
    context.user_data['reaction_count'] = int(query.data.split('_')[1])
    
    # Apaga a mensagem anterior
    query.delete_message()

    # Solicita o ID, link ou @ do canal
    query.message.reply_text("👇 Por favor, insira o @seucanaltelegram! \n Importante: Certifique-se de inserir o @ do seu canal no Telegram. Links ou IDs do canal não funcionam.")

def receber_canal_grupo(update: Update, context: CallbackContext) -> None:
    global bot_ativo

    # Função para validar o formato do canal
    def validar_canal(texto):
        return re.match(r'^@[\w_]+$', texto)

    # Função para pedir ao usuário para digitar novamente
    def pedir_novamente():
        update.message.reply_text("❌ Formato inválido. Digite novamente no formato @nomedousuario:")

    channel_link_or_username = update.message.text.strip()
    reaction_count = context.user_data.get('reaction_count', 0)

    while not validar_canal(channel_link_or_username):
        pedir_novamente()
        return

    if reaction_count:
        context.user_data['channel_link_or_username'] = channel_link_or_username

        bot_ativo = True
        save_preferences(reaction_count, channel_link_or_username, bot_ativo)
        
        # Enviar a mensagem de serviço ativo
        update.message.reply_text(
            "Seu serviço está ativo!",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🛑 Parar", callback_data='parar')]])
        )
        
        # Chamar a função para processar as reações de forma contínua
        threading.Thread(target=processar_reacoes_continuas, args=(reaction_count, channel_link_or_username)).start()

    else:
        update.message.reply_text("Ocorreu um erro. Por favor, tente novamente.")
# Dicionário para armazenar as sessões que já reagiram a uma mensagem
reactions_done = {}

# Variável global para armazenar a ID da última mensagem à qual o bot reagiu
last_message_id = None



async def processar_reacoes(reaction_count: int, channel_link_or_username: str):
    global last_message_id
    global reactions_done

    for session_file in session_files:
        if session_file.endswith(".session"):
            session_name = session_file.replace(".session", "")
            app = Client(session_name, api_id=API_ID, api_hash=API_HASH)

            async with app:
                await app.join_chat(channel_link_or_username)

                message = None  # Inicialize a variável message aqui
                async for message in app.get_chat_history(channel_link_or_username, limit=1):
                    # Se a mensagem é a mesma que a última mensagem à qual o bot reagiu, pare de reagir
                    if message.id == last_message_id:
                        break

                    # Verifique se a sessão já reagiu a esta mensagem
                    if reactions_done.get(session_name, None) == message.id:
                        continue

                    await app.send_reaction(message.chat.id, message.id, random.choice(emojis))
                    
                    # Visualizar a mensagem usando o método raw GetMessagesViews
                    peer = await app.resolve_peer(message.chat.id)
                    await app.invoke(
                        GetMessagesViews(
                            peer=peer,
                            id=[message.id],
                            increment=True
                        )
                    )

                    # Marque esta sessão como tendo reagido a esta mensagem
                    reactions_done[session_name] = message.id

                    # Verifique se atingimos a contagem de reações
                    if len(reactions_done) >= reaction_count:
                        break

                    # Adicione um atraso aleatório antes de reagir à próxima mensagem
                    time.sleep(random.randint(1, 5))

        if len(reactions_done) >= reaction_count:
            break

    # Atualize a ID da última mensagem à qual o bot reagiu
    if message is not None:  # Verifique se a mensagem foi definida antes de acessar seu id
        last_message_id = message.id

def processar_reacoes_continuas(reaction_count: int, channel_link_or_username: str):
    global bot_ativo
    global reactions_done
    while bot_ativo:
        asyncio.run(processar_reacoes(reaction_count, channel_link_or_username))
        # Verifique se atingimos a contagem de reações
        if len(reactions_done) < reaction_count:
            time.sleep(10)
            continue
        reactions_done = {}  # Limpe o dicionário após o processamento das reações


last_message = None

def parar(update: Update, context: CallbackContext) -> None:
    global bot_ativo
    global last_message
    bot_ativo = False

    query = update.callback_query
    query.answer()


    qtd, canal, _ = load_preferences()
    save_preferences(qtd, canal, bot_ativo)
    
    query.delete_message()


    if last_message:
        last_message.delete()


    last_message = query.message.reply_text("O serviço foi interrompido. Volte ao menu anterior para iniciar novamente.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Voltar", callback_data='start')]]))


def repetir_ultimo_pedido(update: Update, context: CallbackContext) -> None:
    qtd, canal, ativo = load_preferences()
    if qtd and canal:
        if ativo:
            update.callback_query.message.reply_text("Seu serviço já está ativo!", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🛑 Parar", callback_data='parar')]]))
        else:
            global bot_ativo
            bot_ativo = True
            save_preferences(qtd, canal, bot_ativo)
            update.callback_query.message.reply_text("Seu serviço está ativo novamente!", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🛑 Parar", callback_data='parar')]]))
            threading.Thread(target=processar_reacoes_continuas, args=(qtd, canal)).start()
    else:
        update.callback_query.answer("Não há nenhum pedido salvo.", show_alert=True)
