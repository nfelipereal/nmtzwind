from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Updater, CommandHandler, CallbackContext, CallbackQueryHandler, MessageHandler, Filters

from menu_servicos import servicos
from menu_reacoes import reacoes, escolher_canal_grupo, receber_canal_grupo, repetir_ultimo_pedido, parar, load_preferences
from menu_ajuda import ajuda

def start(update: Update, context: CallbackContext) -> None:
    user = update.effective_user
    if update.callback_query:
        query = update.callback_query
        query.answer()
        query.delete_message()
        query.message.reply_photo(
            photo=open('assets/main.png', 'rb'),
            caption=f'Boas vindas!, {user.first_name}!\n\nCom o ReactFy, você pode transformar suas interações no Telegram adicionando reações de emojis às mensagens em seus canais favoritos. Torne suas conversas mais divertidas e expressivas!\n\nEscolha uma das opções abaixo para começar:',
            reply_markup=get_menu_keyboard()
        )
    else:
        update.message.reply_photo(
            photo=open('assets/main.png', 'rb'),
            caption=f'Boas vindas!, {user.first_name}!\n\nCom o ReactFy, você pode transformar suas interações no Telegram adicionando reações de emojis às mensagens em seus canais favoritos. Torne suas conversas mais divertidas e expressivas!\n\nEscolha uma das opções abaixo para começar:',
            reply_markup=get_menu_keyboard()
        )

def get_menu_keyboard() -> InlineKeyboardMarkup:
    keyboard = [
       [
            InlineKeyboardButton("▶️ Serviços", callback_data='menu_servicos')
        ],
        [
            InlineKeyboardButton("❓ Ajuda ", callback_data='menu_ajuda')
        ]
    ]
    
    qtd, canal, ativo = load_preferences()
    if qtd and canal:
        keyboard.append([InlineKeyboardButton("🔄 Repetir último pedido", callback_data='repetir_ultimo_pedido')])
    
    return InlineKeyboardMarkup(keyboard)

def main() -> None:
    updater = Updater("6898251767:AAFZe4cnavDxnTr0bZrzK5K7YDk-SDzHNkY", use_context=True)

    dispatcher = updater.dispatcher

    dispatcher.add_handler(CommandHandler("start", start))

    dispatcher.add_handler(CallbackQueryHandler(servicos, pattern='menu_servicos'))
    dispatcher.add_handler(CallbackQueryHandler(reacoes, pattern='menu_reacoes'))
    dispatcher.add_handler(CallbackQueryHandler(start, pattern='start'))
    dispatcher.add_handler(CallbackQueryHandler(escolher_canal_grupo, pattern='enviar_\\d+_reacoes'))
    dispatcher.add_handler(CallbackQueryHandler(repetir_ultimo_pedido, pattern='repetir_ultimo_pedido'))
    dispatcher.add_handler(CallbackQueryHandler(ajuda, pattern='menu_ajuda'))
    dispatcher.add_handler(CallbackQueryHandler(parar, pattern='parar'))
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, receber_canal_grupo))

    updater.start_polling()

    updater.idle()

if __name__ == '__main__':
    main()
